import { requireRole } from "./auth";
import { getProject } from "./projects";
import { githubRepoStore, type RepoStore } from "./repo_store";
import { assertSafeReadPath, STATUS_LABELS } from "./policy";
import { errorResponse, jsonResponse } from "./response";
import type { Env, Role } from "./types";

interface FlowIndexEntry {
  flow_id: string;
  name: string;
  type: string;
  status: string;
  current_gate: string;
  title: string;
  updated_at: string;
}

interface FlowIndex {
  schema_version: string;
  project: string;
  flows: FlowIndexEntry[];
}

interface FlowArtifactSummary {
  artifact_id?: string;
  artifact_type?: string;
  title?: string;
  role?: string;
  created_at?: string;
  source_path?: string;
  source_sha?: string;
}

interface FlowHistoryEvent {
  event_id?: string;
  event_type?: string;
  role?: string;
  created_at?: string;
  note?: string;
}

interface FlowManifest {
  flow_id: string;
  name: string;
  type: string;
  status: string;
  current_gate: string;
  title: string;
  artifacts?: FlowArtifactSummary[];
  history?: FlowHistoryEvent[];
}

interface MutationStateRecord {
  queue_item_id: string;
  flow_ref: string;
  flow_id: string;
  project: string;
  current_state: string;
  claimed_by: Role | null;
  handoff_target_role: string | null;
  updated_at: string;
  latest_mutation_id: string;
}

interface QueueReadError {
  flow_id: string;
  queue_item_id: string;
  error: string;
}

export interface QueueTruthBoundary {
  queue_record_is_truth: false;
  queue_record_is_evidence: false;
  raw_gpt_output_is_evidence: false;
  contextbus_notes_messages_are_evidence: false;
  requires_harness: true;
}

export interface QueueItem {
  queue_item_id: string;
  project: string;
  flow_id: string;
  flow_ref: string;
  queue_lane: "diagnostic";
  current_state: string;
  current_role_owner: string;
  allowed_next_role: string;
  allowed_next_action: string;
  blocked_reason: string | null;
  stop_condition: string | null;
  related_artifacts: Record<string, unknown>[];
  evidence_requirements: unknown[];
  audit_status: "UNKNOWN";
  human_decision_status: "UNKNOWN";
  truth_boundary: QueueTruthBoundary;
}

interface QueueBuildResult {
  queue_items: QueueItem[];
  queue_read_errors: QueueReadError[];
  bounded_scan: {
    applied: boolean;
    max_flows: number;
    total_science_flows: number;
    scanned_science_flows: number;
    stopped_early: boolean;
    stop_reason: string | null;
  };
}

export const TRUTH_BOUNDARY: QueueTruthBoundary = {
  queue_record_is_truth: false,
  queue_record_is_evidence: false,
  raw_gpt_output_is_evidence: false,
  contextbus_notes_messages_are_evidence: false,
  requires_harness: true
};

export const SCIENCE_QUEUE_ROLES: Role[] = [
  "EXPLORER_AI",
  "HYPOTHESIZER_AI",
  "DESIGNER_AI",
  "SCIENCE_AUDITOR_AI",
  "SCIENCE_EXECUTOR_AI",
  "HUMAN"
];

export function getParam(url: URL, name: string): string | null {
  const value = url.searchParams.get(name);
  return value && value.trim() ? value.trim() : null;
}

export function requiredStatusLabels(): string[] {
  return [...STATUS_LABELS];
}

function parseBoundedScanLimit(url: URL): number {
  const raw = getParam(url, "scan_limit") || getParam(url, "limit") || "";
  const parsed = Number.parseInt(raw, 10);
  if (!Number.isFinite(parsed)) return 8;
  return Math.min(Math.max(parsed, 1), 20);
}

function flowIndexPath(): string {
  return "governance/flows/flow_index.json";
}

function flowManifestPath(flowId: string): string {
  return `governance/flows/${flowId}/flow_manifest.json`;
}

function queueMutationStatePath(queueItemId: string): string {
  return `governance/queues/mutations/state/${queueItemId.replace(/[^A-Za-z0-9._-]+/g, "_")}.json`;
}

export async function readQueueMutationState(
  env: Env,
  projectName: string,
  queueItemId: string,
  store: RepoStore
): Promise<MutationStateRecord | null> {
  const project = getProject(projectName);
  if (!project) throw new Error(`Unknown project: ${projectName}`);
  try {
    const file = await store.fetchFile(env, project, queueMutationStatePath(queueItemId));
    return JSON.parse(file.content) as MutationStateRecord;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes("404")) return null;
    throw error;
  }
}

function emptyFlowIndex(project: string): FlowIndex {
  return { schema_version: "flow_index.v0.3", project, flows: [] };
}

function safePath(path: string | undefined): string {
  if (!path) return "UNKNOWN";
  try {
    assertSafeReadPath(path);
    return path;
  } catch {
    return "UNKNOWN_UNSAFE_PATH";
  }
}

function readState(status: string, gate: string): string {
  const normalizedStatus = (status || "").toLowerCase();
  const normalizedGate = (gate || "").toUpperCase();
  if (normalizedStatus === "blocked") return "BLOCKED";
  if (normalizedStatus === "completed") return "COMPLETED_STEP";
  if (normalizedGate.includes("QUARANTINE")) return "QUARANTINED";
  if (normalizedGate.includes("EXECUTOR")) return "WAITING_FOR_EXECUTOR";
  if (normalizedGate.includes("HUMAN")) return "WAITING_FOR_HUMAN";
  if (normalizedGate.includes("BLOCK")) return "BLOCKED";
  if (normalizedStatus === "active") return "READY";
  return "UNKNOWN";
}

function roleFromGate(gate: string): string {
  const normalized = (gate || "").toUpperCase();
  if (normalized.includes("EXPLORER")) return "EXPLORER_AI";
  if (normalized.includes("HYPOTHESIZER")) return "HYPOTHESIZER_AI";
  if (normalized.includes("DESIGNER")) return "DESIGNER_AI";
  if (normalized.includes("AUDITOR")) return "SCIENCE_AUDITOR_AI";
  if (normalized.includes("EXECUTOR")) return "SCIENCE_EXECUTOR_AI";
  if (normalized.includes("HUMAN")) return "HUMAN";
  return "UNKNOWN";
}

function isScienceQueueMutatingRole(role: Role): boolean {
  return ["EXPLORER_AI", "HYPOTHESIZER_AI", "DESIGNER_AI", "SCIENCE_AUDITOR_AI"].includes(role);
}

function allowedNextActionForQueueItem(role: Role, state: string, currentRoleOwner: string, allowedNextRole: string): string {
  if (!isScienceQueueMutatingRole(role)) return "READ_ONLY_RECOMMENDATION_ONLY";

  if (state === "READY") {
    if (currentRoleOwner === "UNKNOWN" || currentRoleOwner === role || allowedNextRole === role) {
      return "CLAIM_ELIGIBLE";
    }
    return "CLAIM_POLICY_CHECK_REQUIRED";
  }

  if (state === "CLAIMED") return "CLAIMED_ITEM_REQUIRES_STATE_RECORD_CHECK";
  if (state === "BLOCKED") return "BLOCKED_ITEM_POLICY_CHECK_REQUIRED";
  if (state === "QUARANTINED") return "READ_ONLY_RECOMMENDATION_ONLY";
  if (state === "COMPLETED_STEP") return "READ_ONLY_RECOMMENDATION_ONLY";

  return "READ_ONLY_RECOMMENDATION_ONLY";
}

function safeArtifacts(artifacts: FlowArtifactSummary[] | undefined): Record<string, unknown>[] {
  return (artifacts || []).map(artifact => ({
    artifact_id: artifact.artifact_id || "UNKNOWN",
    artifact_type: artifact.artifact_type || "UNKNOWN",
    title: artifact.title || "UNKNOWN",
    role: artifact.role || "UNKNOWN",
    created_at: artifact.created_at || "UNKNOWN",
    source_path: safePath(artifact.source_path),
    source_sha: artifact.source_sha || "UNKNOWN"
  }));
}

function visibilityFilter(role: Role, item: QueueItem): boolean {
  if (role === "HUMAN") return true;
  if (role === "SCIENCE_EXECUTOR_AI") {
    return item.current_state === "WAITING_FOR_EXECUTOR" || item.allowed_next_role === "SCIENCE_EXECUTOR_AI";
  }
  if (item.current_role_owner === role || item.allowed_next_role === role) return true;
  if (["READY", "UNKNOWN", "BLOCKED", "QUARANTINED", "HANDOFF_REQUESTED", "COMPLETED_STEP", "WAITING_FOR_HUMAN"].includes(item.current_state)) return true;
  return false;
}

async function overlayMutationStateForItem(
  env: Env,
  projectName: string,
  role: Role,
  item: QueueItem,
  store: RepoStore
): Promise<QueueItem> {
  const mutationState = await readQueueMutationState(env, projectName, item.queue_item_id, store);
  if (!mutationState) return item;

  const effectiveState = mutationState.current_state;
  const effectiveOwner = mutationState.claimed_by || item.current_role_owner;
  const effectiveNextRole = mutationState.handoff_target_role || item.allowed_next_role;

  return {
    ...item,
    current_state: effectiveState,
    current_role_owner: effectiveOwner,
    allowed_next_role: effectiveNextRole,
    allowed_next_action: allowedNextActionForQueueItem(role, effectiveState, effectiveOwner, effectiveNextRole),
    blocked_reason: effectiveState === "BLOCKED" ? "UNKNOWN" : null,
    stop_condition: effectiveState === "QUARANTINED" ? "QUARANTINE_CONDITION_PRESENT" : null
  };
}

async function loadFlowIndex(env: Env, projectName: string, store: RepoStore): Promise<FlowIndex> {
  const project = getProject(projectName);
  if (!project) throw new Error(`Unknown project: ${projectName}`);
  try {
    const file = await store.fetchFile(env, project, flowIndexPath());
    const parsed = JSON.parse(file.content) as FlowIndex;
    if (!Array.isArray(parsed.flows)) return emptyFlowIndex(projectName);
    return parsed;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes("404")) return emptyFlowIndex(projectName);
    throw error;
  }
}

export async function loadManifest(env: Env, projectName: string, flowId: string, store: RepoStore): Promise<FlowManifest | null> {
  const project = getProject(projectName);
  if (!project) throw new Error(`Unknown project: ${projectName}`);
  try {
    const file = await store.fetchFile(env, project, flowManifestPath(flowId));
    return JSON.parse(file.content) as FlowManifest;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes("404")) return null;
    throw error;
  }
}

export async function buildQueueItems(
  env: Env,
  projectName: string,
  role: Role,
  store: RepoStore,
  options: { maxFlows?: number } = {}
): Promise<QueueBuildResult> {
  const SUBREQUEST_BUDGET_UNITS = 20;
  const SUBREQUEST_UNITS_PER_FLOW = 2;
  const flowIndex = await loadFlowIndex(env, projectName, store);
  const scienceFlows = flowIndex.flows.filter(entry => entry.type === "science_flow");
  const maxFlows = options.maxFlows && Number.isFinite(options.maxFlows) ? Math.max(1, Math.floor(options.maxFlows)) : scienceFlows.length;
  const cappedFlows = scienceFlows.slice(0, maxFlows);
  const items: QueueItem[] = [];
  const queueReadErrors: QueueReadError[] = [];
  let stoppedEarly = false;
  let stopReason: string | null = null;
  let subrequestUnitsUsed = 0;

  for (const entry of cappedFlows) {
    const queueItemId = `Q-${entry.flow_id}`;
    if (subrequestUnitsUsed + SUBREQUEST_UNITS_PER_FLOW > SUBREQUEST_BUDGET_UNITS) {
      stoppedEarly = true;
      stopReason = "SUBREQUEST_BUDGET_GUARD";
      break;
    }
    try {
      subrequestUnitsUsed += SUBREQUEST_UNITS_PER_FLOW;
      const manifest = await loadManifest(env, projectName, entry.flow_id, store);
      const currentGate = manifest?.current_gate || entry.current_gate || "UNKNOWN";
      const state = readState(manifest?.status || entry.status || "UNKNOWN", currentGate);
      const nextRole = roleFromGate(currentGate);
      const baseItem: QueueItem = {
        queue_item_id: queueItemId,
        project: projectName,
        flow_id: entry.flow_id,
        flow_ref: manifest?.name || entry.name || entry.flow_id,
        queue_lane: "diagnostic",
        current_state: state,
        current_role_owner: nextRole,
        allowed_next_role: nextRole,
        allowed_next_action: allowedNextActionForQueueItem(role, state, nextRole, nextRole),
        blocked_reason: state === "BLOCKED" ? "UNKNOWN" : null,
        stop_condition: state === "QUARANTINED" ? "QUARANTINE_CONDITION_PRESENT" : null,
        related_artifacts: safeArtifacts(manifest?.artifacts),
        evidence_requirements: [],
        audit_status: "UNKNOWN",
        human_decision_status: "UNKNOWN",
        truth_boundary: TRUTH_BOUNDARY
      };
      const item = await overlayMutationStateForItem(env, projectName, role, baseItem, store);
      if (visibilityFilter(role, item)) items.push(item);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      queueReadErrors.push({
        flow_id: entry.flow_id || "UNKNOWN",
        queue_item_id: queueItemId,
        error: message.slice(0, 280)
      });
      if (/subrequest|1101|too many/i.test(message)) {
        stoppedEarly = true;
        stopReason = "SUBREQUEST_PRESSURE_SUSPECTED";
        break;
      }
    }
  }

  return {
    queue_items: items.sort((a, b) => a.flow_id.localeCompare(b.flow_id)),
    queue_read_errors: queueReadErrors,
    bounded_scan: {
      applied: cappedFlows.length < scienceFlows.length,
      max_flows: maxFlows,
      total_science_flows: scienceFlows.length,
      scanned_science_flows: cappedFlows.length,
      stopped_early: stoppedEarly,
      stop_reason: stopReason
    }
  };
}

function flowIdFromQueueRef(queueRef: string): string | null {
  if (/^Q-FLOW-\d{4}-\d{4}$/.test(queueRef)) return queueRef.slice(2);
  if (/^FLOW-\d{4}-\d{4}$/.test(queueRef)) return queueRef;
  return null;
}

export async function buildQueueItemByRef(
  env: Env,
  projectName: string,
  role: Role,
  queueRef: string,
  store: RepoStore
): Promise<QueueItem | null> {
  const trimmedRef = (queueRef || "").trim();
  if (!trimmedRef) return null;

  let flowId = flowIdFromQueueRef(trimmedRef);
  let entryName = "";

  if (!flowId) {
    const flowIndex = await loadFlowIndex(env, projectName, store);
    const entry = flowIndex.flows.find(candidate =>
      candidate.type === "science_flow" &&
      (candidate.flow_id === trimmedRef || candidate.name === trimmedRef)
    );
    if (!entry) return null;
    flowId = entry.flow_id;
    entryName = entry.name;
  }

  const manifest = await loadManifest(env, projectName, flowId, store);
  if (!manifest || manifest.type !== "science_flow") return null;

  const currentGate = manifest.current_gate || "UNKNOWN";
  const state = readState(manifest.status || "UNKNOWN", currentGate);
  const nextRole = roleFromGate(currentGate);
  const queueItemId = `Q-${manifest.flow_id}`;

  const baseItem: QueueItem = {
    queue_item_id: queueItemId,
    project: projectName,
    flow_id: manifest.flow_id,
    flow_ref: manifest.name || entryName || manifest.flow_id,
    queue_lane: "diagnostic",
    current_state: state,
    current_role_owner: nextRole,
    allowed_next_role: nextRole,
    allowed_next_action: allowedNextActionForQueueItem(role, state, nextRole, nextRole),
    blocked_reason: state === "BLOCKED" ? "UNKNOWN" : null,
    stop_condition: state === "QUARANTINED" ? "QUARANTINE_CONDITION_PRESENT" : null,
    related_artifacts: safeArtifacts(manifest.artifacts),
    evidence_requirements: [],
    audit_status: "UNKNOWN",
    human_decision_status: "UNKNOWN",
    truth_boundary: TRUTH_BOUNDARY
  };

  const overlayed = await overlayMutationStateForItem(env, projectName, role, baseItem, store);
  return visibilityFilter(role, overlayed) ? overlayed : null;
}

function queueResponseBase(projectName: string, role: Role): Record<string, unknown> {
  return {
    ok: true,
    project: projectName,
    authenticated_role: role,
    required_status_labels: requiredStatusLabels(),
    truth_boundary: TRUTH_BOUNDARY,
    no_mutation: true,
    warning: "Queue records are governance coordination records, not evidence or scientific truth."
  };
}

function methodGuard(request: Request): Response | null {
  if (request.method !== "GET") {
    return errorResponse("METHOD_NOT_ALLOWED", `Only GET is allowed for ${new URL(request.url).pathname}`, 405);
  }
  return null;
}

function enforceRoleQuery(url: URL, authenticatedRole: Role): Response | null {
  const requestedRole = getParam(url, "role");
  if (!requestedRole) return null;
  if (authenticatedRole !== "HUMAN" && requestedRole !== authenticatedRole) {
    return errorResponse("ROLE_MISMATCH", `Authenticated role ${authenticatedRole} cannot request ${requestedRole}`, 403);
  }
  return null;
}

function assertScienceQueueRole(role: Role): Response | null {
  if (!SCIENCE_QUEUE_ROLES.includes(role)) {
    return errorResponse("SCIENCE_QUEUE_ROLE_FORBIDDEN", `Role ${role} cannot access read-only science queue`, 403);
  }
  return null;
}

export type ScienceQueueRoute =
  | "list"
  | "item"
  | "by_flow"
  | "next"
  | "blocked"
  | "quarantined"
  | "handoffs"
  | "history";

export async function handleScienceQueueReadRequest(
  request: Request,
  env: Env,
  route: ScienceQueueRoute,
  args: { queueItemId?: string; flowRef?: string } = {},
  repoStore?: RepoStore
): Promise<Response> {
  let projectName = "ArqonZero";
  let role: Role = "HUMAN";
  try {
    const methodError = methodGuard(request);
    if (methodError) return methodError;

    role = requireRole(request, env);
    const roleError = assertScienceQueueRole(role);
    if (roleError) return roleError;

    const url = new URL(request.url);
    const roleQueryError = enforceRoleQuery(url, role);
    if (roleQueryError) return roleQueryError;

    projectName = getParam(url, "project") || "ArqonZero";
    if (!getProject(projectName)) return errorResponse("UNKNOWN_PROJECT", `Unknown project: ${projectName}`, 404);

    const store = repoStore || githubRepoStore;
    const base = queueResponseBase(projectName, role);

    if (route === "item" || route === "history") {
      const queueItemId = args.queueItemId || "";
      const match = await buildQueueItemByRef(env, projectName, role, queueItemId, store);
      if (!match) return errorResponse("QUEUE_ITEM_NOT_FOUND", `Unknown queue item: ${queueItemId}`, 404);
      if (route === "item") return jsonResponse({ ...base, queue_item: match });

      const manifest = await loadManifest(env, projectName, match.flow_id, store);
      const history = (manifest?.history || []).map(event => ({
        event_id: event.event_id || "UNKNOWN",
        event_type: event.event_type || "UNKNOWN",
        role: event.role || "UNKNOWN",
        created_at: event.created_at || "UNKNOWN",
        note: event.note || ""
      }));
      return jsonResponse({ ...base, queue_item: match, history });
    }

    if (route === "by_flow") {
      const flowRef = args.flowRef || "";
      const match = await buildQueueItemByRef(env, projectName, role, flowRef, store);
      if (!match) return errorResponse("QUEUE_FLOW_NOT_FOUND", `No queue items for flow ref: ${flowRef}`, 404);
      return jsonResponse({ ...base, queue_items: [match] });
    }

    const queueBuild = await buildQueueItems(env, projectName, role, store, { maxFlows: parseBoundedScanLimit(url) });
    const items = queueBuild.queue_items;

    if (route === "list") return jsonResponse({ ...base, ...queueBuild });

    if (route === "next") {
      const nextItem = items.find(item => item.allowed_next_role === role) || items[0] || null;
      return jsonResponse({ ...base, ...queueBuild, queue_item: nextItem });
    }

    if (route === "blocked") return jsonResponse({ ...base, ...queueBuild, queue_items: items.filter(item => item.current_state === "BLOCKED") });
    if (route === "quarantined") return jsonResponse({ ...base, ...queueBuild, queue_items: items.filter(item => item.current_state === "QUARANTINED") });
    if (route === "handoffs") {
      const handoffs = items.filter(item => item.allowed_next_role !== "UNKNOWN").map(item => ({
        queue_item_id: item.queue_item_id,
        flow_id: item.flow_id,
        from_role: item.current_role_owner,
        to_role: item.allowed_next_role,
        handoff_note: "READ_ONLY_HANDOFF_VISIBILITY_ONLY"
      }));
      return jsonResponse({ ...base, ...queueBuild, handoffs });
    }

    return errorResponse("QUEUE_ROUTE_NOT_IMPLEMENTED", `Unsupported queue route: ${route}`, 404);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return jsonResponse({
      ok: false,
      project: projectName,
      authenticated_role: role,
      no_mutation: true,
      truth_boundary: TRUTH_BOUNDARY,
      required_status_labels: requiredStatusLabels(),
      error: {
        code: "INTERNAL_QUEUE_LIST_ERROR",
        message
      }
    }, 500);
  }
}
